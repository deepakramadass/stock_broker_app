/** server with reusable logic, better organization,
 * and unit tests using 3_util.c logic 
 * @ author Deepak Ramadass
 */

#include "common.h"
#include "3_util.h"

int stop = 0;
int sock = 0;
int GOOG = 200;
int BAC = 200;
struct addrinfo *listen_addr = NULL;
char *output = NULL;
uint8_t my_responses[100] = {0};
uint8_t seq_num_store[100] = {0};

/**
  * This function checks the number of share corresponding to GOOG
  * and BAC are available and reduces the global value by the no. of
  * units.
  * @param name - the name of the stock, units - the no. of shares
  * @return 0/1 - success/failure
*/
int check_shares(char *name,uint8_t units){
	if (strncmp(name,"GOOG",4) == 0)
	{
		if(GOOG >= units){
			GOOG-= units;
			return 0;
		}
		else
			return 1;
	}
	else if (strncmp(name,"BAC",3) == 0)
	{
		if(BAC >= units){
			BAC-= units;
			return 0;
		}
		else
			return 1;
	}
	else
	{
		return 1;
	}
	

}

/**
  * This function processes the data received by a single client,
  * calls the check_shares function, constructs the BOUGHT packect,
  * and resends BOUGHT packets if the sequence numbers were seen before
  * @param torec points to the BUY packet
  * @param client_addr points to the address to send the BOUGHT packet
  * @return returns the size of the BOUGHT packet for unittesting
*/
int handle_client(struct buy *torecv, 
		struct sockaddr_storage *client_addr)
{
	if(torecv->code != 1)
		return 1;
	printf("NEW BUY PACKET:\n");
	printf("seq_num: %u\n", ntohl(torecv->seq_num));
	
	char name[5] = {'\0'}; 
	strncpy(name,torecv->name,4);
	printf("name: %s\n", name);
	
	uint8_t length = torecv->quantity_length;
	char *roman_numeral = malloc(length +1);
	memcpy(roman_numeral,&(torecv->quantity),length);
	roman_numeral[length] = '\0';
		
	struct bought tosend;
	tosend.code = 2;
		
	if(check_for_invalid_inputs(roman_numeral) == 1){
		tosend.status_code = 2;
		goto label1;
	}
	if(my_responses[ntohl(torecv->seq_num)] != 0){
		printf("resending packect with seq_num %u\n",ntohl(torecv->seq_num));
		tosend.seq_num = htonl(torecv->seq_num);
		tosend.status_code = my_responses[ntohl(torecv->seq_num)];
	}
	
	else{
		uint8_t units = roman_to_number(roman_numeral);
		printf("QUANTITY REQUESTED %u\n",units);
		printf("STOCKS AVAILABLE GOOG: %d  BAC: %d \n",GOOG,BAC);

		if(check_shares(name, units) == 0)
			tosend.status_code = 1;
		else
			tosend.status_code = 2;
		
	label1:	tosend.seq_num = htonl(torecv->seq_num);
		my_responses[ntohl(torecv->seq_num)] = tosend.status_code;
	}
	
	send_data(&tosend, sizeof(struct bought), client_addr);
	free(roman_numeral);
	return sizeof(tosend);
}

//run with port # as the first argument
//talk to using netcat, e.g.: nc -u ::1 10689
