/**
 * @file unittest.c
 * @author Justin Yackoski, Deepak Ramadass
 * @brief This file contains my unit tests.
 */
#include <stddef.h>
#include <stdarg.h>
#include <setjmp.h>
#include <cmocka.h>
#include "common.h"
#include "3_util.h"

static char printf_output[MAXLENGTH]; 
struct bought *test; ///< bought test packet

/**
 * Wrapper of getaddrinfo
 * @param node
 * @param service
 * @param hints 
 * @param res
 * @return 0 success 1 failure
 */

int __wrap_getaddrinfo(const char *node, const char *service,
		const struct addrinfo *hints,
		struct addrinfo **res)
{
	*res = malloc(sizeof(struct addrinfo));
	return (int)mock();
}

/**
 * Wrapper of sendto
 * @param sockfd
 * @param buf
 * @param len 
 * @param flags
 * @param dest_addr
 * @param addrlen
 * @return actuallen
 */

size_t __wrap_sendto(int sockfd, const void *buf, size_t len, int flags,
	const struct sockaddr *dest_addr, socklen_t addrlen)
{
	size_t actuallen = (size_t)mock();
	return actuallen;
}

/**
 * Wrapper of recvfrom
 * @param sockfd
 * @param buf
 * @param len 
 * @param flags
 * @param src_addr
 * @param addrlen
 * @return actuallen
 */

ssize_t __wrap_recvfrom(int sockfd, void *buf, size_t len, int flags,
	struct sockaddr *src_addr, socklen_t *addrlen)
{
	size_t actuallen = (size_t)mock();
	//void* answer = mock_ptr_type(void *);
	memcpy(buf, test, 6);
	return actuallen;
}
/**
 * Wrapper of printf
 * @param format
 * @return len
 */

int __wrap_printf(const char *format, ...)
{
	va_list(argptr);
	va_start(argptr, format);
	int len = vsnprintf(printf_output, MAXLENGTH, format, argptr);
	if (len >= MAXLENGTH)
	{
		assert_in_range(len, 0, MAXLENGTH-1);
		printf_output[MAXLENGTH-1] = 0;
	}
	va_end(argptr);
	return len;
}
/**
 * Wrapper of socket 
 * @param domain
 * @param type
 * @param protocol
 * @return sock
 */

int __wrap_socket(int domain, int type, int protocol)
{
	int sock = (int)mock();
	return sock;
}

/*static void prepare_addr_test(void **state)
{
	struct addrinfo *send_addr = NULL;
	will_return(__wrap_getaddrinfo, 0);
	assert_int_equal(prepare_addr("::1", "10689", &send_addr), 0);
	free(send_addr);
}

static void prepare_addr_test_failure(void **state)
{
	struct addrinfo *send_addr = NULL;
	will_return(__wrap_getaddrinfo, 1);
	assert_int_equal(prepare_addr("::1", "10689", &send_addr), 1);
	assert_non_null(send_addr);
	free(send_addr);
}
*/

/**
 * This function tests handle_clients
 * and checks if its returns a Bought packet
 * of size 6 bytes
 */
static void handle_clients_test(void **state)
{
	//struct sockaddr_storage *client_add;
	struct buy *test_packet;
	test_packet = malloc(sizeof(struct buy) + 2);
	test_packet->code = 1;
	test_packet->seq_num = htonl(10);
	strncpy(test_packet->name,"GOOG",4);
	test_packet->quantity_length = 2;
	char *string = &(test_packet->quantity);
	string[0] = 'x';
	string[1] = 'i';
	//char recvstr[] = "ABC is 3 bytes";
	//size_t len = sizeof(test_packet) + 1;
	//will_return(__wrap_recvfrom, len);
	//will_return(__wrap_recvfrom, (uintptr_t)test_packet);
	//will_return(__wrap_sendto,6);
	assert_int_equal(handle_client(test_packet,NULL),6);
	//assert_string_equal(printf_output,);
	free(test_packet);
}

/**
 * This function tests client functionality
 */
static void client_test(void **state)
{
	test = malloc(6);
	test->code = 2;
	test->status_code = 1;
	test->seq_num = htonl(10);
        char name[4] = "GOOG";
        char output[] = "XX";
        uint8_t quanlen = 2;
	size_t len = 12;
        will_return(__wrap_getaddrinfo, 0);
	will_return(__wrap_sendto,len);
	will_return(__wrap_socket,0);
        will_return(__wrap_recvfrom,len);
	//will_return(__wrap_recvfrom, (uintptr_t)test);
        assert_int_equal((client(name,output,quanlen,"::1","10689")),0);
        free(test);
}



/**
 * This function starts the test program.
 * @return the exit code of the program
 */
int main(void)
{
	const struct CMUnitTest tests[] =
	{
		//cmocka_unit_test(prepare_addr_test),
		//cmocka_unit_test(prepare_addr_test_failure),
		//cmocka_unit_test(do_send_recv_test),
		cmocka_unit_test(handle_clients_test),
		cmocka_unit_test(client_test),
	};

	return cmocka_run_group_tests(tests, NULL, NULL);
}
