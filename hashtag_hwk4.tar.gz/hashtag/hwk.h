/**
 * @file hwk.h
 * @author Deepak Ramadass, Pooja Burly Prakash, Deepika Rajarajan
 * @brief This is the header file.
 */
#ifndef HWK_H
#define HWK_H
#include <stdio.h>
#include <stdint.h>
#include <string.h>

/**
 * @brief This is my structure for storing data
 * values stores the stock prices
 * value_names store the stock names
 * num_values store the number of stocks
 * __attribute__ ((packed)) ensure struct is packed 
 */
struct STOCKS{
	int64_t* values; ///<the values being stored
	char ** value_names; ///<the names are stored
	size_t num_values; ///< how many values there are
}__attribute__((packed));///<used to pack

void store_name(char* name, int line);
void store_value(int64_t value, int line);
void open_file();
void close_file();
int startup_mode(char *data[]);
int check_arguments(char* line);
int initialize(size_t num);
void database_cleanup();
/**
  *this pointer provides access to the struct stocks
*/
extern struct STOCKS *database;
int transaction_mode(char *ip,char *port);
int buy(char stockname[],int num_units);
int sell(char *name, int units);
int statement();
int quote (char stock_name[]);
int deposit(int64_t dollars);
int withdraw(int64_t dollars);
int cmdcaps(char stock[]);
int numcheck(char numinput[]);
/**
  * this variable store user balance and stock prices
*/
extern int64_t *user_data;
#endif
