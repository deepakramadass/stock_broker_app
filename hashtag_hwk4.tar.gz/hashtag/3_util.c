/* utility functions for common things */
#include "3_util.h"

//this function sends a generic data buffer
void send_data(void *data, int datalen, 
		struct sockaddr_storage *client_addr)
{
	socklen_t addr_len = sizeof(struct sockaddr_storage);

	if (client_addr != NULL)
	{
		ssize_t bytes_sent = sendto(sock, data, datalen, 0,
			(struct sockaddr *) client_addr, addr_len);
		if (bytes_sent < 0)
		{
			exit_with_error("sendto failed");
		}
	}
	else
	{
		sprint_hex(data, datalen);
	}
}

//this function prints a generic data buffer to
//the "output" char array (for unit testing)
void sprint_hex(uint8_t *data, size_t length)
{
	char myoutput[MAXLENGTH];
	char tmp[MAXLENGTH];
	assert(length < 100);
	myoutput[0] = '\0';

	int i;
	for (i = 0; i < length; i++)
	{
		sprintf(tmp, "%02x ", data[i]);
		strcat(myoutput, tmp);
		if (i % 16 == 15)
		{
			strcat(myoutput, "\n");
		}
	}
	if (myoutput[strlen(myoutput)-1] != '\n')
	{
		strcat(myoutput, "\n");
	}
	//printf("%s\n",myoutput);
	//output = strdup(myoutput);
};

//This function listens for possible clients
//and invokes the handler for each
void receive_clients()
{
	while (!stop)
	{
		struct sockaddr_storage client_addr;
		int datalen = sizeof(struct buy) + MAXLENGTH;
		struct buy *torecv = NULL;
		torecv = malloc(datalen);
		socklen_t addr_len = sizeof(struct sockaddr_storage);
		
		ssize_t bytes = recvfrom(sock, torecv, 
					datalen, 0,
					(struct sockaddr *) &client_addr,
					&addr_len);
		if (stop)
		{       
			free(torecv);
			break;
		}

		if (bytes < 0)
		{
			exit_with_error("recvfrom failed");
		}
		assert(bytes <= 2010);

		handle_client(torecv, &client_addr);
		free(torecv);
	}

}

void handler2(int signal)
{
	stop = 1;
	if (sock != 0)
	{
		close(sock);
	}
}

void cleanup()
{
	if (listen_addr)
		freeaddrinfo(listen_addr);
	if (sock)
		close(sock); 
}

void exit_with_error(char *msg)
{
	perror(msg);
	cleanup();
	exit(1);
}

void register_handler()
{
	struct sigaction actinfo;
	actinfo.sa_handler = handler2;
	sigfillset(&actinfo.sa_mask); //todo check for error
	actinfo.sa_flags = 0;
	sigaction(SIGINT, &actinfo, 0); //todo check for error
	sigaction(SIGHUP, &actinfo, 0); //todo check for error
	sigaction(SIGTERM, &actinfo, 0); //todo check for error
}

void prepare_socket(int argc, char *argv[])
{
	struct addrinfo lookup_addr;
	memset(&lookup_addr, 0, sizeof(struct addrinfo));
	lookup_addr.ai_family = AF_INET6; //or AF_INET
	lookup_addr.ai_flags = AI_PASSIVE;
	lookup_addr.ai_socktype = SOCK_DGRAM;
	lookup_addr.ai_protocol = IPPROTO_UDP;

	if (getaddrinfo(NULL, argv[1], &lookup_addr, &listen_addr) != 0)
	{
		exit_with_error("getaddrinfo failed");
	}

	sock = socket(listen_addr->ai_family, listen_addr->ai_socktype,
			listen_addr->ai_protocol);
	if (sock < 0)
	{
		exit_with_error("socket failed");
	}
	if (bind(sock, listen_addr->ai_addr, 
				listen_addr->ai_addrlen) < 0)
	{
		exit_with_error("bind failed");
	}

}
