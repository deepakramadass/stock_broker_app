/* header file for 3_util.c */
#include "common.h"

#ifndef UTIL_H_3
#define UTIL_H_3

extern int stop;
extern int sock;
extern struct addrinfo *listen_addr;
extern char *output;

//this function needs to be implemented by someone
//(it is not in 3_util.c!)
int handle_client(struct buy *torecv, 
		struct sockaddr_storage *client_addr);

void send_data(void *data, int datalen, 
		struct sockaddr_storage *client_addr);

void receive_clients();

void sprint_hex(uint8_t *data, size_t length);

void handler2(int signal);

void cleanup();

void exit_with_error(char *msg);

void register_handler();

void prepare_socket(int argc, char *argv[]);

#endif 
