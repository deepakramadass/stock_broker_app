/**
 * @file main.c
 * @author Deepak Ramadass,Deepika Rajarajan
 * @brief This is the main file that starts the program.
 */
#include "hwk.h"
#include "common.h"
/**
 * This is the main function that starts the program.
 * @param argc the number of arguments
 * @param argv the command line arguments 
 *   (the 0th argument is the program name)
 * @return  0 the exit code of the program
 */
int main(int argc, char *argv[])
{	
	srandom(time(NULL));
	//Check if arguments are given else error is thrown into console
        if (argc >3 || argc <3)
        {
                fprintf(stderr,"Error: Please enter valid number of input arguments\n");
		exit(1);
        }
        else
        {
		if(argc==3)
		{
		struct addrinfo lookup_addr;
        	memset(&lookup_addr, 0, sizeof(struct addrinfo));
        	lookup_addr.ai_family = AF_INET6;
        	lookup_addr.ai_socktype = SOCK_DGRAM;
        	lookup_addr.ai_protocol = IPPROTO_UDP;
        	struct addrinfo *send_addr;
        		if (getaddrinfo(argv[1],argv[2], &lookup_addr, &send_addr)!=0)
        		{
        			 
        			perror("getaddrinfo failed");
        			printf("Invalid Ip or port\n");	
        			exit(1);
        		}
		freeaddrinfo(send_addr);
			/*if(lookup_addr.ai_family == AF_INET6)
			{
                	printf("%s is an ipv6 address\n",argv[1]);
                	}               
                	else 
                	{
                	printf("%s is an is unknown address format\n",argv[1]);
                	exit(1);
                	}
			
	

		int i;
		printf("%s\n",argv[2]);
		for(i=0;strlen(argv[2]);i++)
		{			
			if((argv[2][i]>='0') && (argv[2][i] <='9'))
				continue;
			else{
			fprintf(stderr,"Error: Please enter valid input argument\n");
			exit(1);
			}
		}*/
		}
		
	}
	
		startup_mode(argv);	
	return 0;
}

