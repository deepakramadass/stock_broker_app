#include "common.h"

/**
  * Used to check if invalid roman numerals were entered.
  * Checks for known cases like "iiii","ixi","ivi","ccvc","ll","vv"
  * Assumes that the input is all lower case.
  * This happens when the user is not aware of the roman numeral format
  * Terminates program if inputs are invalid
  * @param input_string contains lower case roman numeral that was entered
 */
int check_for_invalid_inputs(char *input_string){
	 convert_to_lower(input_string);
	 int i = 0, v = 0, x = 0, l = 0, c = 0;
         int pointer = 0;
         while(input_string[pointer] != '\0'){
		if(input_string[pointer] == 'i' && i < 3 && (((input_string[pointer + 1] == 'x' || input_string[pointer + 1] == 'v') && (input_string[pointer + 2] != 'i')) || input_string[pointer + 1] == 'i' || input_string[pointer+1] == '\0'))
			i++;
		else if(input_string[pointer] == 'v' && v == 0)	
			v++;
		else if(input_string[pointer] == 'x' && x <= 3)
			x++;
		else if(input_string[pointer] == 'l' && l == 0)
			l++;
		else if(input_string[pointer] == 'c' && c < 2)
			c++;
		else
			return 1;
		pointer++;
	}
	return 0;
}

/**
 * This function is used to identify 4,9,40 and 90,
 * as they are special cases in Roman Numerals.
 * @param inp points to two chararcters at a time
 * of the input entered.
 * @return the number if the special case exits 
 */
uint8_t check_special_case(char *inp){
	uint8_t number = 0;	
	if(inp[0] == 'i' && inp[1] == 'v')
		number =  4;
	else if(inp[0] == 'i' && inp[1] == 'x')
		number =  9;
	else if(inp[0] == 'x' && inp[1] == 'l')
		number =  40;
	else if(inp[0] == 'x' && inp[1] == 'c')
		number =  90;
	else
		number =  0;
	return number;
}

/**
  * This function converts the input received to
  * lower case, thus reducing all comparisons to lower
  * case alphabets.
  * @param input_string contains the roman numeral entered.
  * @return the entire roman numeral in lower case 
 */
void convert_to_lower(char *input_string){
	int i = 0;
	for(i = 0; input_string[i] != '\0'; i++)
		input_string[i] = tolower(input_string[i]);
}

/**
  * This function calculates the value of the roman numeral,
  * the vales are summed up to calculate the integer value of the roman numeral.
  * (except for specials cases handled by check_special_case function).
  * @param inp contains the roman numeral digit whose value needs to calculated.
  * @return the value of the roman numeral digit
 */
int8_t get_value(char inp){
       uint8_t number = 0;
	switch(inp){
		case 'i':
			number = 1;
			break;
		case 'v':
			number = 5;
			break;
		case 'x': 
			number = 10;
			break;
		case 'l':
			number = 50;
			break;
		case 'c':
			number = 100;
	       default: break;
	}
	return number;
}

/**
 * returns the integer value of the roman number,
 * converts the roman numeral to lower case and checks
 * for special cases(ix,iv,xc,xl) and get its vaule if it exits 
 * or gets the value of each roman numeral digit and adds it to "number".
 * Assumes that a vail roman numeral is passed to it.
 * Throws an error if number exceed 255.
 * @param src contains the roman number 
 * @return the integer value of the roman number
 */
uint8_t roman_to_number(char *src)
{        
	char input_string[1000] = {};
	//char *conversion_pointer;
	//conversion_pointer = input_string;
	char inp[2] = {};
	uint8_t number = 0;
	uint8_t compare = 0;
	strcpy(input_string,src);
	convert_to_lower(input_string);
	//check_for_invalid_inputs(conversion_pointer);
	int i = 0;
	for(i = 0; input_string[i] != '\0'; i++){
       		inp[0] = input_string[i];
		if(input_string[i+1] != '\0')
			inp[1] = input_string[i+1];
		number+= check_special_case(inp);
		if(number != compare)
			i++;
		else
			number+= get_value(input_string[i]);
                //if(number < compare)
			//parse_error();	
		compare = number;
		}
	return number;

}

/** 
  * This function converts the one's digit of number to its
  * corresponding roman numeral representation.
  * @param store is used to store the output
  * @param digit contains the one's digit
  * @return the roman numeral corresponding to the one's digit.
*/
void get_ones_roman(char *store, int digit){
	int i = 0;
	switch(digit){
		case 0: store[0] = '\0';
		case 1:
		case 2:
		case 3:
			
			for(i = 0;i < digit;i++)
				 store[i] = 'i';
			store[digit] = '\0';
			break;
		case 4:
			store[0] = 'i';
			store[1] = 'v';
			store[2] = '\0';
			break;
		case 5:
		case 6:
		case 7:
		case 8:
			store[0] = 'v';
			for(i = 1;i <=(digit-5);i++)
				store[i] = 'i';
			store[digit-4] = '\0';
			break;
		case 9:
			store[0] = 'i';
			store[1] = 'x';
			store[2] = '\0';
			break;
		default :
			break;	
	}
}

/** 
  * This function converts the ten's digit of number to its
  * corresponding roman numeral representation.
  * @param store is used to store the output
  * @param digit contains the ten's digit
  * @return the roman numeral corresponding to the ten's digit.
*/
void get_tens_roman(char *store, int digit){
	int i = 0;
	switch(digit){
		case 0: store[0] = '\0';
		case 1:
		case 2:
		case 3:
			for(i = 0;i < digit;i++)
				 store[i] = 'x';
			store[digit] ='\0';
			break;	
		case 4:
			store[0] = 'x';
			store[1] = 'l';
			store[2] = '\0';
			break;	
		case 5:
		case 6:
		case 7:
		case 8:
			store[0] = 'l';
			for(i = 1;i <= (digit-5);i++)
				store[i] = 'x';
			store[digit-4] = '\0';
			break;	
		case 9:
			store[0] = 'x';
			store[1] = 'c';
			store[2] = '\0';
			break;					
	}
}
 
/** 
  * This function converts the hundred's digit of number to its
  * corresponding roman numeral representation. It assumes that
  * 2 is the greatest hundreth digit that will exist.
  * @param store is used to store the output
  * @param digit contains the hundred's digit
  * @return the roman numeral corresponding to the hundred's digit.
*/
 void get_hundreds_roman(char *store, int digit){
	int i = 0;
	switch(digit){
		case 0: store[0] = '\0';
		case 1:
		case 2:
			for(i = 0;i < digit; i++)
				store[i] = 'c'; 
			store[digit] = '\0';
		default:break;					
	}
}



/**
 * called to change the number back to a roman numeral
 * it seperates the number into one's,tens's and hundred's 
 * digit, calls the corresponding functions to get their
 * roman numeral representations.
 * @param dst stores the roman numeral that is obtained
 * @param number to be coverted
 * @return the size of the roman numeral obtained.
 */
size_t number_to_roman(char *dst, uint8_t number)
{	
	char store[sizeof(dst)] = {};
	uint8_t ones_digit = number % 10;
	uint8_t tens_digit = (number/10) % 10;
 	uint8_t hundreds_digit = number / 100;
 	dst[0] = '\0';
 	get_hundreds_roman(store, hundreds_digit);
 	strncat(dst,store,strlen(store));
 	get_tens_roman(store, tens_digit);
 	strncat(dst,store,strlen(store));
 	get_ones_roman(store, ones_digit);
 	strncat(dst,store,strlen(store));
 	return strlen(dst)+1;
}
