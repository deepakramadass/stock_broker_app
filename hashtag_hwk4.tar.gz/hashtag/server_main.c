/**
 * @file server_main.c
 * @author Deepak Ramadass
 * @brief This file contains my main.
 */
#include "common.h"
#include "3_util.h"

/**
 * This is the main function that starts the program.
 * @param argc the number of arguments
 * @param argv the command line arguments 
 *   (the 0th argument is the program name)
 * @return  0 the exit code of the program
 */
int main(int argc, char *argv[])
{
	if (argc > 2)
	{
		exit(1);
	}
	int i = 0;
	for(i = 0; i <strlen(argv[1]); i++){
		if(argv[1][i] >= '0' && argv[1][i] <='9')
			continue;
		else
			exit(1);
	}
	register_handler();
	prepare_socket(argc, argv);
	receive_clients();
	cleanup();

	return 0;
}
