/**
 * @file hwk.c
 * @author Deepika Rajarajan,Fnu Deepak Ramadass,Pooja BurlyPrakash 
 * @brief This file contains all the functions of the program
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include "hwk.h"
#include "common.h"
#define SIZE 1000 ///< the max length of line
#define LOG(cmd) fprintf(log_file,"%s ERROR INVALID INPUT\n",strtok(cmd,"\r\n")) ///< Logs invalid commands
#define LOG_FUNDS(cmd) fprintf(log_file,"%s INSUFFICIENT FUNDS\n",strtok(cmd,"\r\n")) ///< logs insufficient funds

int64_t FEE = 0; ///< store the FEE
struct STOCKS *database = NULL;
int64_t *user_data;
//char received_cmd[10];
char str[] = "\0"; ///< to find end of arrays;
char line_store[SIZE] = {}; ///< temp store of line for operation
FILE *log_file; ///< points to log file
char line[SIZE]; ///< stores the line
char log_line[SIZE]= {}; ///< store line for logging
char *ip; ///< loopback ip 
char *port; ///< 10689 port used 
char output1[SIZE];///< to store output from number to roman  
char nameinp[4]; ///< to store stock name
/**
 * Opens the file
 */
void open_file(){
	log_file = fopen("log.txt","w");
	if(log_file == NULL){
		printf("Unable to open log file");
		exit(1);
	}
}

/**
 * Closes the the file
 */
void close_file(){
	fclose(log_file);
}

/**
 * Error function
 * @return 1 
 */
int error(){
	printf("ERROR INVALID INPUT\n");
	return 1;
}

/**
 * Function that returns number of characters in the roman numeral
 * @param dst input data 
 * @return count return the number of characters
 */
uint8_t num_units_quanlen(char *dst)
{

        int i;
        int count = 0;
        for (i=0;dst[i]!='\0';i++)
        {
        count++;
        }
return count;
}
/**
 * Function that prints No shares available for purchase
 * @return 1
 */
int no_shares()
{
        printf("NO SHARES AVAILABLE FOR PURCHASE\n");
        return 1;
}
/**
 * Function that prints Communication error
 * @return 1
 */

int communication_error()
{
        printf("COMMUNICATION ERROR\n");
        return 1;
}
 /**
 * Register handler for client
 */

void client_register_handler()
{
        struct sigaction actinfo;
        actinfo.sa_handler = handler;
        sigfillset(&actinfo.sa_mask);
        actinfo.sa_flags = 0;
        sigaction(SIGALRM, &actinfo, 0);
}

/**
 * Throws Insufficient funds at console
 * @return 1 
 */
int insuff_funds(){
	printf("INSUFFICIENT FUNDS\n");
	return 1;
}

/**
 * initializes my array of numbers
 * @param num the number of numbers
 * @return 1 if failure, 0 if success
 */
int initialize(size_t num)
{
	database = malloc(sizeof(struct STOCKS));
	if (database == NULL)
	{
		printf("uh oh\n");
		return 1;
	}

	database->num_values = num;
	database->values = malloc(sizeof(int64_t) *(num));
	database->value_names = malloc(sizeof(char *) * (num));
	user_data = calloc(num+1,sizeof(int64_t));
	user_data[0] = 0;
	if ( database->values == NULL && database->value_names == NULL && user_data == NULL)
	{
		printf("uh oh\n");
		return 1;
	}
	return 0;
}

/**
 * cleans up my array of numbers
 */
void database_cleanup()
{
	if (database == NULL || database->values == NULL || database->value_names == NULL || user_data == NULL)
	{
		printf("uh oh\n");
	}
	free(database->values);
	database->values = NULL;
	int count = (database->num_values) - 1;
	while(count >= 0){
		free(database->value_names[count]);
		count--;
	}
	free(database->value_names);
	database->value_names = NULL;
	database->num_values = 0;
	free(user_data);
	user_data = NULL;
	free(database);
	database = NULL;
}

/** 
  * Function used to store stock names
  * @param token holds the stock name
  * @param lines holds the position of the stock in the array
*/
void store_name(char* token, int lines){
	database->value_names[lines] = strdup(token);		
}

/** 
  * Function used to store stock value
  * @param value holds the stock value
  * @param lines holds the position of the stock in the array
*/
void store_value(int64_t value, int lines){
	(*database).values[lines] = value;
}

/**
 * Function to buy stocks from the loaded stock database
 * @param stockname[] name of the stock
 * @param num_units is the number of stocks to be bought
 * @return 1 if failure, 0 if success
 */
int buy(char stockname[],int num_units)
{
        int64_t total;
        int64_t stockprice;
        int i=0;
        int priceval = 0;
	int64_t old_price;
	int64_t new_price;
//Check if Num of stocks is 0 and return Error
        if(database->num_values==0)
        {
	error();
        LOG(log_line);
	fflush(log_file);
        return 1;
        }
//Check if the received stockname is matching with the stocknames in user database 
//Storing number of units to be bought in user database
        for(i=0;i<database->num_values;i++)
        {
                if(strcmp(stockname,database->value_names[i])==0)
                {
                stockprice = database->values[i];
                user_data[i+1]+=num_units;
                priceval = i;
		goto label4;
                }
        }
	error();
        LOG(log_line);
	fflush(log_file);
	return 1;
label4:     total = num_units*stockprice;
//Check if user balance is not equal to 0 else print insufficient funds
        if(user_data[0]!=0)
        {
//Check if the shares to be bought is less than balance+fee
                if((total)<=user_data[0]-8)
                {
//Check if user balance is >= 10000 for no fee charge and reduce price of stock to $1
                	if(user_data[0]>=10000)
                	{
			
                	user_data[0] = user_data[0]-(total);       
                	}
//User balance less than 10000 fee charge of $8 and reduce the price od stock to $1
                	else
               	 	{
			FEE = 8;
                	user_data[0] = user_data[0]-(total)-FEE;
                	}
                }
//Check insufficient funds
                else
		{
		insuff_funds();
		LOG_FUNDS(log_line);
		fflush(log_file);
                return 1;
                }
        }
        else
        {
	insuff_funds();
	LOG_FUNDS(log_line);
	fflush(log_file);
        return 1;
        }
		

       	old_price = database->values[priceval];
       	database->values[priceval] = database->values[priceval]-1;
//Check if stock price hits 0 and print error
	if(database->values[priceval]<0)
	{
	database->values[priceval]=0;
	error();
	LOG(log_line);
	fflush(log_file);
	return 1;
	}
        new_price = database->values[priceval];	
	printf("%d SHARES OF %s BOUGHT FOR $%lld TOTAL ~~~ BALANCE NOW $%lld\n",num_units,stockname,total,user_data[0]);
	fprintf(log_file,"BUY %s %d BALANCE $%lld FEE $%lld %s %lld $%lld $%lld\n",stockname,num_units,user_data[0],FEE,stockname,user_data[priceval+1],old_price,new_price);
	fflush(log_file);
return 0;
}

/**
 * Deposits the amount specified by the user and adds to the user balance
 *@param dollars amount of money to be deposited
 *@return Function returns 0 if success
 */
int deposit (int64_t dollars)
{
//add amount specified by the user to the user balance
//and display the current user balance
	user_data[0] = user_data[0] + dollars;
	printf("$%lld DEPOSITED ~~~ BALANCE NOW $%lld\n",dollars,user_data[0]);
	fprintf(log_file,"DEPOSIT $%lld BALANCE $%lld FEE $%lld - - - -\n",dollars,user_data[0],FEE);
	fflush(log_file);
	return 0;

}

/**
 * Withdraws the amount specified by the user from the user balance database
 * @param dollars Amount of dollars to be withdrawn
 * @return 1 if failure, 0 if success
 */

int withdraw (int64_t dollars)
{
//Check if user balance is not 0
        if(user_data[0]!=0)
        {
//Check if withdraw amount is less than or equal to balance&fee 
                if(dollars<=user_data[0]-10)
                {
//Check if user balance is > $10000 for no fee charge
                        if(user_data[0]>=10000)
                        {
                        user_data[0] = user_data[0]-dollars;
                        printf("HERE IS YOUR $%lld ~~~ BALANCE NOW $%lld\n",dollars,user_data[0]);
			fprintf(log_file,"WITHDRAW BALANCE $%lld FEE $%lld ----\n",user_data[0],FEE);
			fflush(log_file);
                        }
//Check if user balance is < $10000 for fee charge of $10
                        else if(user_data[0]<10000)
                        {
			FEE = 10;
                        user_data[0] = (user_data[0]-(dollars)-FEE);
                        printf("HERE IS YOUR $%lld ~~~ BALANCE NOW $%lld\n",dollars,user_data[0]);
			fprintf(log_file,"WITHDRAW BALANCE $%lld FEE $%lld ----\n",user_data[0],FEE);
			fflush(log_file);
                        }
                }
                else
                {
		insuff_funds();
		LOG_FUNDS(log_line);
		fflush(log_file);
                return 1;
                }
        }
        else
        {
	insuff_funds();
	LOG_FUNDS(log_line);
	fflush(log_file);
        return 1;
        }
return 0;
}

/** Quotes the current stock price of a stock specified by the user
 * @param stock_name[] User specified stock name
 * @return returns 1 in case of any error and 0 if success
 */
int quote (char stock_name[])
{
        int64_t i = 0;
        int64_t old_price = 0;
        int64_t fee_amt = 0;
        int pos = 0;
//Check if number of stocks is 0
        if(database->num_values==0)
        {
	LOG(log_line);		
	error();
	fflush(log_file);
        return 1;
        }
//Check if user balance is greater than 1 else print insufficient funds
        if (user_data[0] > 1)
        {

                for (i = 0; i<database->num_values; i++)
                {
//checks if the user has entered a valid stock name
                       	if (strcmp(stock_name,database->value_names[i]) == 0)

                       	{
                       	        pos = i;
                       	        old_price = database->values[i];
//checks if the user owns any stocks for the entered stock name
                       	        if (user_data[i+1] == 0)
                       	        {
                       	                database->values[i] = database->values[i] + 1;
                       	        }
                       	        else if (user_data[i+1] >= 1)
                       	        {
                       	                database->values[i] = database->values[i] - 1;
					if (database->values[i] < 0)
						database->values[i] = 0;
                               	}
                        	goto label5;
                       	}
                }
               	LOG(log_line);
		fflush(log_file);
		error();
                return 1;
//checks if the user has $10000 or more in their account to determine the fees
               label5:  if ((user_data[0] + database->values[pos]) >= 10000)
                {
                        fee_amt = 0;
                }
                else
                {
                        fee_amt = 1;
                }
                user_data[0] = user_data[0] - fee_amt;
		printf("%s IS $%lld\n",stock_name,database->values[pos]);
		if (old_price == 0)
		{
			fprintf(log_file,"QUOTE %s BALANCE $%lld FEE $%lld %s - $%lld -\n",stock_name,user_data[0],fee_amt,stock_name,old_price);
		}
		else
		{
                	fprintf(log_file,"QUOTE %s BALANCE $%lld FEE $%lld %s - $%lld $%lld\n",stock_name,user_data[0],fee_amt,stock_name,old_price,database->values[pos]);
		}
		fflush(log_file);
        }
        else
        {	
		LOG_FUNDS(log_line);
		fflush(log_file);
		insuff_funds();
		return 1;
        }
        return 0;
}

/**
  * The sell fuctions checks if the user balance is above 10000
  * and charges fee accodingly, it also checks if the stock is bankrupy
  * and prints an error is sell is used on a bankrupt stock
  * It sell stocks, add the sale to balance, increases stock price by 1 and reduces no.of stocks owned
  * @param name is the stock name
  * @param units is number of stocks to be sold
  * @return 0/1 - success/error
*/	
int sell(char *name, int units){
	if(user_data[0] >= 10000)
		FEE = 0;
	else
		FEE = 8;
	int count = 0;
	while( count < database->num_values){
		if(strcmp(name,(database->value_names[count])) == 0)
			break;
		count++;
	}
	if(count >= database->num_values){
		LOG(log_line);
		error();
		fflush(log_file);
		return 1;
	}
	int64_t price = database->values[count];
	if(price <= 0){
		error();
		LOG(log_line);
		fflush(log_file);
		return 1;
	}
	if(units > user_data[count+1]){
		LOG(log_line);
		error();
		fflush(log_file);
		return 1;
	}
	user_data[0]+= (price * units);
	if(user_data[0] < FEE){
		LOG(log_line);
		error();
		fflush(log_file);
		return 1;
	}		
	(database->values[count])++;	
	user_data[0]-= FEE;
	user_data[count+1]-= units;
	printf("%d SHARES OF %s SOLD FOR $%lld TOTAL ~~~ BALANCE NOW $%lld\n",units,name,(price * units),user_data[0]);
	fprintf(log_file,"SELL %s %d BALANCE $%lld FEE $%lld %s %lld $%lld $%lld\n",name,units,user_data[0],FEE,name,user_data[count+1],price,price+1);
	fflush(log_file);
	return 0;
}

/**
  * The statement function prints the total balance,individual stocks and prices
  * reduces the fee accordingly 
  * @return 0/1 - success/error
*/
int statement(){
	if(user_data[0] >= 10000)
		FEE = 0;
	else
		FEE = 2;
	int64_t funds_check = user_data[0] - FEE;
	if(funds_check < 0){
		LOG_FUNDS(log_line);
		fflush(log_file);
		insuff_funds();
		return 1;
	}
	printf("BALANCE NOW $%lld\n",(user_data[0] - FEE));
	printf("STOCK\tSHARES\tPRICE\tTOTAL\n");
	int num = (database->num_values)-1;
	int64_t TOTAL = 0;
	int count = 0;
	while(count <= num){
		int64_t units = user_data[count+1];
		if(units == 0){
			count++;
			continue;
		}
		int64_t price = database->values[count];
		if(price <= 0){
			count++;
			continue;
		}
		int64_t total = units * price; 
		TOTAL+= total;
		printf("%s\t%lld\t$%lld\t$%lld\n",(database->value_names[count]),units,price,total);
		count++;
	}
	TOTAL = TOTAL + user_data[0] - FEE;
	if(count > num)
		printf("ACCOUNT VALUE $%lld\n",TOTAL);
	user_data[0]-= FEE;
	fprintf(log_file,"STATEMENT BALANCE $%lld FEE $%lld - - - -\n",user_data[0],FEE);	
	fflush(log_file);
	return 0;
}

/**
  * Funtions finds the number of strings in a line
  * @param line points to the line
  * @return tokens - the number of strings
*/
int check_arguments(char* line){
        char *token = strtok(line," ");
        int tokens = 0;
        while(token != NULL){
                token = strtok(NULL, " ");
                tokens++;
        }
        return tokens;
}

/**
 * Checks the capitalization of the input string given
 * @param stock[] stockname
 * @return 1 if failure, 0 if success
 */
int cmdcaps(char stock[])
{
	int i;
	for(i=0;stock[i]!='\0';i++)
	{
	if(stock[i]>='A' && stock[i]<='Z')
	{
	}
	else
	{
	return 1;
	}
	}
return 0;
}

/**
 * Validation for string of numbers
 * @param numinput character array of numbers
 * @return 1 if failure, 0 if success
 */

int numcheck(char numinput[])
{
int i;
	for(i=0;numinput[i]!='\0';i++)
	{
		if((numinput[i]>='0') && (numinput[i]<='9'))
		{
		}
		else
		{
		return 1;
		}	
	}
return 0;
}

/**
 * Coverts to uppercase
 * @param data character array 
 * @return 0 if success
 */

int uppercase(char data[])
{
	int i =0;
	for(i=0;data[i]!='\0';i++)
	{
	data[i] = toupper(data[i]);
	}
	return 0;
}
/**
 * Enters into transaction mode
 * Validates the input arguments and checks the validation of each argument
 * Calls the transaction functions BUY,SELL,DEPOSIT,WITHDRAW,STATEMENT,QUOTE
 * @param ip ip for transfer
 * @param port port for transfer
 * @return 1 if failure, 0 if success
 */

int transaction_mode(char* ip,char* port)
{
	char line[SIZE]={};
	int num_units=0;
	int64_t dollars=0;
	int arg_check=0;
	printf("TRANSACTION MODE READY\n");
	label3: if(fgets(line,SIZE,stdin)== NULL)
	{		
		return 1;
	}
	strcpy(log_line,line);
	strcpy(line_store,line);
	arg_check = check_arguments(line_store);	
	char input1[SIZE]={0};
	char input2[SIZE] ={0};
 	char input3[SIZE] = {0};
	uint8_t quanlen;	
	sscanf(line_store,"%s",input1);
//Checks if transaction command is in caps
		if(cmdcaps(input1)!=0)
		{
		LOG(log_line);
		error();
		fflush(log_file);
		goto label3;
		}
//Checks if buy or sell transaction
		if(strcmp(input1,"BUY")==0 || strcmp(input1,"SELL")==0)
		{
			if(arg_check != 3)
			{
			LOG(log_line);
			error();
			fflush(log_file);
			goto label3;
			}
			sscanf(line,"%s %s %s",input1,input2,input3);
			 if(cmdcaps(input2)!=0 || input2[4]!=0 || numcheck(input3)!=0)
			{
				LOG(log_line);
				error();
				fflush(log_file);
				goto label3;	
			}
			num_units = atoi(input3);
			if(num_units>100)
			{
			printf("Only 100 shares may be bought or sold\n");
                        goto label3;
			}	
//Buy transaction
			if(strncmp(input1,"BUY",3)==0)
			{
//Check if the received stockname is matching with the stocknames in user database	 
        		int k=0;
        		int count = 0;
			int64_t total1 = 0;
		        int64_t stockprice1 = 0;
        		for(k=0;k<database->num_values;k++)
        		{
                	if(strncmp(input2,database->value_names[k],4)==0)
                	{
  			count=count+1;
			stockprice1= database->values[k];
			goto label6;
                	}
			}
		label6:	if(count!=1)
			{
			LOG(log_line);
                        error();
                        fflush(log_file);
                        goto label3;
                	}
//Check insufficient funds
			total1 = stockprice1*num_units;
                	if((user_data[0]==0) || (total1>user_data[0]-8))
                	{
                	insuff_funds();
                	LOG_FUNDS(log_line);
                	fflush(log_file);
                	goto label3;
               		}
			if(stockprice1 == 0)
			{
			LOG(log_line);
                        error();
                        fflush(log_file);
                        goto label3;
			}

//Convert the units got from the user to roman numeral
			number_to_roman(output1,num_units);
//Convert the roman numeral to uppercase
			uppercase(output1);
//Call function num_units_quanlen to find out the number of characters in roman numeral
			quanlen = num_units_quanlen(output1);			
			int i;
			char nameinp[4];
			char input2copy[SIZE]={};
			char *nameinp2;
			strcpy(input2copy,input2);
			nameinp2 = strtok(input2copy," ");
//Stock name when a character is Null replaces with whitespace character
			for(i=0;i<4;i++)
        		{
        		if(nameinp2[i]=='\0')
        		{
        		nameinp2[i] =' ';
        		}
			else
			{
			nameinp2[i]=nameinp2[i];
        		}
			}
			strncpy(nameinp,nameinp2,4);
		 	int clientresult=0;
//Check result from client
			clientresult = client(nameinp,output1,quanlen,ip,port);
			if (clientresult == 0)
			{
			buy(input2,num_units);
			goto label3;	
			}
			else
			{
			goto label3;
			}
			}
//Sell transaction
			if(strcmp(input1,"SELL")==0)
			{
			sell(input2,num_units);
			goto label3;
			}
			
		}
//Checks deposit and withdraw transaction
		else if(strcmp(input1,"DEPOSIT")==0 || strcmp(input1,"WITHDRAW")==0)
		{
			
			if(arg_check!=2)
			{
			LOG(log_line);
			error();
			fflush(log_file);
			goto label3;
			}
			sscanf(line,"%s %s",input1,input2);
			char *stockinp;
			stockinp = input2+1;
			if(input2[0]!='$'||numcheck(stockinp)!=0)
			{
			LOG(log_line);
			error();
			fflush(log_file);
			goto label3;
			}
			dollars = atoi(stockinp);
//Deposit transaction
			if(strcmp(input1,"DEPOSIT")==0)
			{
			deposit(dollars);
			goto label3;
			}
//Withdraw transaction
			if(strcmp(input1,"WITHDRAW")==0)
			{
			withdraw(dollars);
			goto label3;
			}	
                        
		}
//Checks quote transaction
		else if(strcmp(input1,"QUOTE")==0)
		{
                        if(arg_check!=2)
			{
			LOG(log_line);
			error();
			fflush(log_file);
			goto label3;
			}
			sscanf(line,"%s %s",input1,input2);
				if(cmdcaps(input2)!=0)
				{
				LOG(log_line);
				error();
				fflush(log_file);
				goto label3;
				}
				else
				{
				quote(input2);
				goto label3;
				}
		}
//Checks statement transaction
		else if(strcmp(input1,"STATEMENT")==0)
		{
			if(arg_check!=1)
			{
			LOG(log_line);
			error();
			fflush(log_file);
			goto label3;
			}
			sscanf(line,"%s",input1);
			statement();
			goto label3;		
		}
		else
		{
		LOG(log_line);
		error();
		fflush(log_file);
		goto label3;
		}
return 0;
}

/**
  * This function checks the initial STOCK commands and
  * intializes the database and store the stock names and values
  * it checks if the STOCKS/STOCKS command is present first and
  * then the approprite pattern STOCKS Num/ STOCK xyx value
  * It throws an error is Num/ value is <= 0 and expects xyx to be uppercase.
  * @param data gets ip and port 
  * @return 0/1 if successful/failure
*/
int startup_mode(char* data[]){
	printf("STARTUP MODE READY\n");
	char line[SIZE];
	char cmd[SIZE];
	size_t num;
	int length = 0;
	int64_t value = 0;
	int result = 0;
	open_file();
label1: if(fgets(line,SIZE,stdin) == NULL){
		return 1;
	}
	strcpy(log_line,line);
	strcpy(line_store,line);
	if(check_arguments(line_store) != 2){
		LOG(log_line);
		error();
		fflush(log_file);
		goto label1;
	}
	if(sscanf(line,"%6s",cmd) == EOF){
		LOG(log_line);
		error();
		fflush(log_file);
		goto label1;
	}
	if(strcmp(cmd,"STOCKS") != 0){
		LOG(log_line);
		error();
		fflush(log_file);
		goto label1;
	}
	result = sscanf(line,"STOCKS %d",&length);
	if(length <= 0){
		LOG(log_line);
		error();
		fflush(log_file);
		goto label1;
	}
	num = length;
	if(result != 1){
		LOG(log_line);
		error();
		fflush(log_file);
		goto label1;
	}
	if(initialize(num) !=0){
		LOG(log_line);
		error();
		fflush(log_file);
		goto label1;
	}                    
	fprintf(log_file,"STOCKS %d BALANCE $0 FEE $0 - - - -\n",num);
	fflush(log_file);
	
	int lines = 0;
	char tokens[4] = {};
	
label2:	while(lines < num && fgets(line,SIZE,stdin) != NULL){	
		strcpy(log_line,line);
		strcpy(line_store,line);
		if(sscanf(line,"%5s",cmd) == EOF){
			LOG(log_line);
			error();
			fflush(log_file);
			goto label2;
		}
		if(check_arguments(line_store) != 3){
			LOG(log_line);
			error();
			fflush(log_file);
			goto label2;
		}
		if(strcmp(cmd,"STOCK") != 0){
			LOG(log_line);
			error();
			fflush(log_file);
			goto label2;
		}
		//strcpy(line_store,line);
		if((result = sscanf(line,"STOCK %4[A-Z] $%lld",tokens,&value) != 2)){
			LOG(log_line);
			error();
			fflush(log_file);
			goto label2;
		}
		if(value <= 0){
			LOG(log_line);
			error();
			fflush(log_file);
			goto label2;
		}
		int count = 0;
		while(count < lines){
				if(strncmp(tokens,(database->value_names[count]),4) == 0){
				
					LOG(log_line);
					error();
					fflush(log_file);
					goto label2;
				}
			count ++;
		}
		store_value(value,lines);
		store_name(tokens,lines);	
		fprintf(log_file,"STOCK %s $%lld BALANCE $0 FEE $0 - - - -\n",tokens,value);
		fflush(log_file);
		lines++;
	}
//	printf("data[1] = %s\n",data[1]);
//	printf("data[2] = %s\n",data[2]);
	ip = data[1];
	port = data[2];
//	printf("ip = %s\n",ip);
//	printf("port = %s\n",port);
	transaction_mode(ip,port);
        database_cleanup();
	fclose(log_file);
	return 0;
}
