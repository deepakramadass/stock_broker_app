/**
 * @file client.c
 * @author Justin Yackoski, Deepika Rajarajan 
 * @brief Client with reused logic from 1_clientrexmit.c
 */

#include "common.h"
//run with ip and port as arguments
//talk to using netcat e.g:
//nc -u -l -k -w 0 ::1 10689
/**
 * client program
 * @param nameinp name of the stock
 * @param output units in roman numeral
 * @param quanlen number of characters of roman numeral
 * @param ip ip used in transfer
 * @param port 10689 used in transfer
 * @return 1 failure 0 success
 */

int client(char nameinp[4],char output[],uint8_t quanlen,char ip[],char port[])
{
	client_register_handler();

	struct addrinfo lookup_addr;
        memset(&lookup_addr, 0, sizeof(struct addrinfo));
        lookup_addr.ai_family = AF_UNSPEC;
        lookup_addr.ai_socktype = SOCK_DGRAM;
        lookup_addr.ai_protocol = IPPROTO_UDP;
        struct addrinfo *send_addr;
        if (getaddrinfo(ip,port, &lookup_addr, &send_addr)!=0)
        {
	#ifdef DEBUG 
        perror("getaddrinfo failed");
	#endif
	communication_error();
        LOG_COMM_ERROR;
        fflush(log_file);
	freeaddrinfo(send_addr);
        return 1;
        }
        int sock = socket(send_addr->ai_family,send_addr->ai_socktype,send_addr->ai_protocol);
        if(sock<0)
        {
	#ifdef DEBUG
        perror("socket failed");
	#endif
	communication_error();
        LOG_COMM_ERROR;
        fflush(log_file);
	freeaddrinfo(send_addr);
        return 1;
        }

	struct bought torecv;
	int datalen = sizeof(struct buy) + (quanlen -1);
	struct buy *tosend = malloc(datalen);
	tosend->code = 1;
	tosend->seq_num = htonl(random() %254 +1);
//Stock name is no null terminator
	char *strname = tosend->name;
	int j;
	for(j=0;j<4;j++)
        {
                        strname[j] = nameinp[j];
        }
	tosend->quantity_length = quanlen;
//quanity_length with no null terminator
	char *strquan = &(tosend->quantity);
	int i = 0;
	for(i=0;i<quanlen;i++)
	{
                        strquan[i] = output[i];
	}
	ssize_t bytes_sent = sendto(sock, tosend, datalen, 0, 
			send_addr->ai_addr, send_addr->ai_addrlen);
	if(bytes_sent !=datalen)
	{
	#ifdef DEBUG 
	perror("sendto failed");
	#endif
	communication_error();
        LOG_COMM_ERROR;
        fflush(log_file);
	freeaddrinfo(send_addr);
        free(tosend);
	close(sock);	
	return 1;
	}

//Set alarm for 2 secs
	alarm(2);
	
	socklen_t addr_len = send_addr->ai_addrlen;
	ssize_t bytes = recvfrom(sock, &torecv, sizeof(struct bought), 0,send_addr->ai_addr, &addr_len);
	if(errno != EINTR)
	{
		if(bytes < 0)
		{
			#ifdef DEBUG
			perror("recvfrom failed");
			#endif
			communication_error();
        		LOG_COMM_ERROR;
        		fflush(log_file);
			freeaddrinfo(send_addr);
        		free(tosend);
			close(sock);
			return 1;
		}
	}
	
	else
	{
		errno = 0;
		int timer;
//Resend the packet to 5 times
		for(timer = 0; timer <5;timer++)
		{
		alarm(2);
		bytes_sent = sendto(sock, tosend, datalen, 0, send_addr->ai_addr, send_addr->ai_addrlen);
		bytes = recvfrom(sock, &torecv, sizeof(struct bought), 0, send_addr->ai_addr, &addr_len);
			if(errno != EINTR)
			{	
				if(bytes<0)
				{
					#ifdef DEBUG
					perror("recvfrom failed\n");
					#endif
					communication_error();
        				LOG_COMM_ERROR;
        				fflush(log_file);
					freeaddrinfo(send_addr);
        				free(tosend);
					close(sock);
					return 1;
				}
				else if(bytes>0)
				{
					goto label1;
				}
			}
			else
			{
			errno = 0;
			}
		}
		
		if(timer>=5)
		{
		alarm(0);
		communication_error();
		LOG_COMM_ERROR;
		fflush(log_file);
		freeaddrinfo(send_addr);
        	free(tosend);
		close(sock);
		return 1;

		}
	}
	if(bytes > 0)
	{
//if bytes are received then turn off the alarm
	label1:	alarm(0);	
	}
	else
	{
	communication_error();
        LOG_COMM_ERROR;
        fflush(log_file);
        freeaddrinfo(send_addr);
        free(tosend);
        close(sock);
	return 1;
	}
	if(torecv.status_code == 2)
	{
	no_shares();
	LOG_NOSHARES;
	fflush(log_file);
	freeaddrinfo(send_addr);
        free(tosend);
	close(sock);
	return 1;
	}
	else if (torecv.status_code == 1)
	{
	}
	else
	{
	freeaddrinfo(send_addr);
        free(tosend);
        close(sock);
	return 1;
	}
	freeaddrinfo(send_addr);
        free(tosend);
        close(sock);
return 0;
}
