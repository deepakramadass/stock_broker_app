#include "common.h"

void handler(int signal)
{
	#ifdef DEBUG
	perror("I got an alarm!\n");
	#endif
}
