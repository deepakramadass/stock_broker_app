
#ifndef COMMON_H
#define COMMON_H
//#define DEBUG


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netdb.h>
#include <unistd.h>
#include <assert.h>
#include <errno.h>
#include <signal.h>
#include <arpa/inet.h>
#include <stdint.h>
#include <ctype.h>
#include <time.h>
#define MAXLENGTH 2000
#define LOG(cmd) fprintf(log_file,"%s ERROR INVALID INPUT\n",strtok(cmd,"\r\n")) ///< Logs invalid commands
#define LOG_COMM_ERROR fprintf(log_file, "COMMUNICATION ERROR\n");
#define LOG_NOSHARES fprintf(log_file, "NO SHARES AVAILABLE FOR PURCHASE\n");
FILE *log_file;//points to log file
//char input1[MAXLENGTH]={0};
//char input2[MAXLENGTH] ={0};
//char input3[MAXLENGTH] = {0};

/**
  * The BUY structs defiines the contents of the BUY packet
*/
struct buy
{
	uint8_t code;		///< code set to 1 to indicate BUY packet
        uint32_t seq_num;	///< seq_num used for identify packets
	char name[4];		///< name corresponds to the STOCK name which needs to bought
	uint8_t quantity_length;///< quantity_lenght is the number of characters in quantity
	char quantity;		///< quantity is the roman numeral of units to be bought
} __attribute__ ((packed));	///< compress the struct

/**
  * This BOUGHT struct defines the BOUGHT packet
*/
struct bought
{
        uint8_t code;		///< code is set to 2 indicating BOUGHT packet
        uint32_t seq_num;	///< seq_num is used to identify packets
        uint8_t status_code; 	///< status_code represents success or failure
} __attribute__ ((packed));	///< compress the struct

int check_for_invalid_inputs(char *input_string);
int handle_client(struct buy *torecv, 
		struct sockaddr_storage *client_addr);
int check_shares(char *name,uint8_t units);
void handler(int signal);
void open_file();
void close_file();
int check_arguments(char* line);
uint8_t check_special_case(char *inp);
int8_t get_value(char inp);
uint8_t roman_to_number(char *src);
size_t number_to_roman(char *dst, uint8_t number);
uint8_t num_units_quanlen(char *dst);
void convert_to_lower(char *input_string);
void get_ones_roman(char *store, int digit);
void get_tens_roman(char *store, int digit);
void get_hundreds_roman(char *store, int digit);
int client(char nameinp[4],char output[],uint8_t quanlen,char ip[], char port[]);
int no_shares();
int communication_error();
void client_register_handler();
int client_prepare_socket(char ip[],char port[]);
#endif
